-- ============================================================
--  MediConnect — Supabase Schema
--  Run this in: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- Enable UUID generation
create extension if not exists "uuid-ossp";

-- ============================================================
--  PROFILES (extends Supabase auth.users)
-- ============================================================
create table public.profiles (
  id            uuid references auth.users(id) on delete cascade primary key,
  name          text not null,
  role          text not null default 'patient' check (role in ('patient','doctor','admin')),
  dob           date,
  blood_type    text,
  weight        numeric(5,2),
  allergies     text[] default '{}',
  insurance     text,
  emergency_contact text,
  created_at    timestamptz default now()
);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'role', 'patient')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
--  DOCTORS
-- ============================================================
create table public.doctors (
  id            uuid default uuid_generate_v4() primary key,
  user_id       uuid references public.profiles(id) on delete cascade,
  name          text not null,
  specialty     text not null,
  rating        numeric(3,2) default 5.0,
  reviews       integer default 0,
  wait_min      integer default 10,
  avatar        text,          -- initials e.g. "AO"
  color         text,          -- hex accent color
  available     boolean default true,
  fee           numeric(8,2),
  bio           text,
  qualifications text[] default '{}',
  languages     text[] default '{English}',
  timezone      text default 'UTC',
  license_no    text,
  verified      boolean default false,
  created_at    timestamptz default now()
);

-- ============================================================
--  APPOINTMENTS
-- ============================================================
create table public.appointments (
  id            uuid default uuid_generate_v4() primary key,
  patient_id    uuid references public.profiles(id) on delete cascade not null,
  doctor_id     uuid references public.doctors(id) on delete cascade not null,
  status        text default 'scheduled' check (status in ('scheduled','completed','cancelled')),
  date          date not null,
  time          text not null,   -- e.g. "10:00 AM"
  reason        text,
  notes         text,
  created_at    timestamptz default now()
);

-- ============================================================
--  CONSULTATIONS
-- ============================================================
create table public.consultations (
  id            uuid default uuid_generate_v4() primary key,
  patient_id    uuid references public.profiles(id) on delete cascade not null,
  doctor_id     uuid references public.doctors(id) on delete cascade not null,
  appointment_id uuid references public.appointments(id),
  status        text default 'active' check (status in ('active','closed')),
  started_at    timestamptz default now(),
  ended_at      timestamptz,
  duration      integer   -- minutes
);

-- ============================================================
--  MESSAGES
-- ============================================================
create table public.messages (
  id            uuid default uuid_generate_v4() primary key,
  consultation_id uuid references public.consultations(id) on delete cascade not null,
  sender_id     uuid references public.profiles(id) on delete cascade not null,
  text          text not null,
  created_at    timestamptz default now()
);

-- ============================================================
--  VITALS
-- ============================================================
create table public.vitals (
  id            uuid default uuid_generate_v4() primary key,
  patient_id    uuid references public.profiles(id) on delete cascade not null,
  bp            text,           -- e.g. "120/80"
  hr            integer,        -- bpm
  temp          text,           -- e.g. "98.6°F"
  spo2          text,           -- e.g. "98%"
  weight        numeric(5,2),
  glucose       integer,        -- mg/dL
  recorded_at   timestamptz default now()
);

-- ============================================================
--  PRESCRIPTIONS
-- ============================================================
create table public.prescriptions (
  id            uuid default uuid_generate_v4() primary key,
  patient_id    uuid references public.profiles(id) on delete cascade not null,
  doctor_id     uuid references public.doctors(id) on delete cascade not null,
  consult_id    uuid references public.consultations(id),
  drug          text not null,
  dose          text not null,
  refills       integer default 0,
  pharmacy      text,
  status        text default 'active' check (status in ('active','filled','expired')),
  issued_at     date default current_date
);

-- ============================================================
--  NOTIFICATIONS
-- ============================================================
create table public.notifications (
  id            uuid default uuid_generate_v4() primary key,
  user_id       uuid references public.profiles(id) on delete cascade not null,
  type          text check (type in ('appointment','prescription','reminder','general')),
  title         text not null,
  body          text,
  read          boolean default false,
  created_at    timestamptz default now()
);

-- ============================================================
--  ROW LEVEL SECURITY (RLS)
-- ============================================================

alter table public.profiles       enable row level security;
alter table public.doctors        enable row level security;
alter table public.appointments   enable row level security;
alter table public.consultations  enable row level security;
alter table public.messages       enable row level security;
alter table public.vitals         enable row level security;
alter table public.prescriptions  enable row level security;
alter table public.notifications  enable row level security;

-- Profiles: users can only read/update their own
create policy "profiles: own read"   on public.profiles for select using (auth.uid() = id);
create policy "profiles: own update" on public.profiles for update using (auth.uid() = id);

-- Doctors: anyone authenticated can read
create policy "doctors: authenticated read" on public.doctors for select using (auth.role() = 'authenticated');

-- Appointments: patient sees own
create policy "appointments: patient read" on public.appointments for select using (auth.uid() = patient_id);
create policy "appointments: patient insert" on public.appointments for insert with check (auth.uid() = patient_id);
create policy "appointments: patient update" on public.appointments for update using (auth.uid() = patient_id);

-- Consultations: patient or doctor in session
create policy "consultations: participant read" on public.consultations for select
  using (auth.uid() = patient_id or auth.uid() = (select user_id from public.doctors where id = doctor_id));
create policy "consultations: patient insert" on public.consultations for insert with check (auth.uid() = patient_id);
create policy "consultations: participant update" on public.consultations for update
  using (auth.uid() = patient_id or auth.uid() = (select user_id from public.doctors where id = doctor_id));

-- Messages: participants in the consultation
create policy "messages: participant read" on public.messages for select
  using (exists (
    select 1 from public.consultations c
    where c.id = consultation_id
    and (auth.uid() = c.patient_id or auth.uid() = (select user_id from public.doctors where id = c.doctor_id))
  ));
create policy "messages: participant insert" on public.messages for insert
  with check (auth.uid() = sender_id);

-- Vitals: own only
create policy "vitals: own read"   on public.vitals for select using (auth.uid() = patient_id);
create policy "vitals: own insert" on public.vitals for insert with check (auth.uid() = patient_id);

-- Prescriptions: own only
create policy "prescriptions: own read" on public.prescriptions for select using (auth.uid() = patient_id);

-- Notifications: own only
create policy "notifications: own read"   on public.notifications for select using (auth.uid() = user_id);
create policy "notifications: own update" on public.notifications for update using (auth.uid() = user_id);

-- ============================================================
--  REALTIME (for live chat)
-- ============================================================
-- Enable realtime on messages table in Supabase Dashboard:
--   Database → Replication → Tables → enable "messages"

-- ============================================================
--  SEED DATA — Sample doctors
-- ============================================================
insert into public.doctors (name, specialty, rating, reviews, wait_min, avatar, color, available, fee, bio, qualifications, languages, timezone, license_no, verified)
values
  ('Dr. Amara Osei',    'General Medicine', 4.9, 312,  5, 'AO', '#0ea5e9', true,  45, 'Board-certified internist with 12 years of experience.',          array['MD - Johns Hopkins','FACP Board Certified','12 yrs experience'], array['English','French'],     'EST', 'GM-44821', true),
  ('Dr. Lena Fischer',  'Dermatology',      4.8, 198, 12, 'LF', '#8b5cf6', true,  65, 'Specialist in medical and cosmetic dermatology.',                  array['MD - Stanford','AAD Member','8 yrs experience'],                array['English','German'],     'PST', 'DM-33912', true),
  ('Dr. Marcus Webb',   'Mental Health',    4.9, 445,  8, 'MW', '#10b981', true,  75, 'Licensed psychiatrist focused on anxiety and CBT.',                array['MD - Columbia','Board Cert Psychiatry','15 yrs experience'],    array['English','Spanish'],    'CST', 'MH-77643', true),
  ('Dr. Priya Nair',    'Pediatrics',       5.0, 267,  3, 'PN', '#f59e0b', true,  55, 'Pediatric specialist from infancy through adolescence.',           array['MD - UCSF','AAP Fellow','10 yrs experience'],                   array['English','Hindi'],      'PST', 'PD-22187', true),
  ('Dr. James Carvalho','Cardiology',       4.7, 189, 20, 'JC', '#ef4444', false, 90, 'Cardiologist specializing in heart disease prevention.',           array['MD - Mayo Clinic','ACC Fellow','18 yrs experience'],            array['English','Portuguese'], 'EST', 'CA-55039', true),
  ('Dr. Sofia Reyes',   'Nutrition',        4.8, 134,  6, 'SR', '#14b8a6', true,  40, 'Registered dietitian helping patients achieve health goals.',      array['RD - UCLA','MS Nutrition','6 yrs experience'],                  array['English','Spanish'],    'MST', 'NT-11204', true);
