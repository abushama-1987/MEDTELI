// lib/supabase.js
// ============================================================
//  Supabase client — drop-in replacement for the in-memory API
//  Install: npm install @supabase/supabase-js
// ============================================================

import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error('Missing EXPO_PUBLIC_SUPABASE_URL or EXPO_PUBLIC_SUPABASE_ANON_KEY in .env');
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false, // Required for React Native
  },
});

// ============================================================
//  AUTH
// ============================================================
export const AuthAPI = {
  async signUp({ email, password, name }) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { name } },
    });
    if (error) throw error;
    return data;
  },

  async signIn({ email, password }) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  async getSession() {
    const { data: { session } } = await supabase.auth.getSession();
    return session;
  },

  onAuthStateChange(callback) {
    return supabase.auth.onAuthStateChange(callback);
  },
};

// ============================================================
//  PROFILE
// ============================================================
export const ProfileAPI = {
  async get(userId) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    if (error) throw error;
    return data;
  },

  async update(userId, updates) {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .single();
    if (error) throw error;
    return data;
  },
};

// ============================================================
//  DOCTORS
// ============================================================
export const DoctorsAPI = {
  async list({ specialty, availableOnly } = {}) {
    let query = supabase.from('doctors').select('*').order('rating', { ascending: false });
    if (specialty && specialty !== 'All') query = query.eq('specialty', specialty);
    if (availableOnly) query = query.eq('available', true);
    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  async get(doctorId) {
    const { data, error } = await supabase
      .from('doctors')
      .select('*')
      .eq('id', doctorId)
      .single();
    if (error) throw error;
    return data;
  },
};

// ============================================================
//  APPOINTMENTS
// ============================================================
export const AppointmentsAPI = {
  async list(patientId) {
    const { data, error } = await supabase
      .from('appointments')
      .select(`*, doctor:doctors(*)`)
      .eq('patient_id', patientId)
      .order('date', { ascending: false });
    if (error) throw error;
    return data;
  },

  async create({ patientId, doctorId, date, time, reason }) {
    const { data, error } = await supabase
      .from('appointments')
      .insert({ patient_id: patientId, doctor_id: doctorId, date, time, reason })
      .select(`*, doctor:doctors(*)`)
      .single();
    if (error) throw error;

    // Create notification
    await supabase.from('notifications').insert({
      user_id: patientId,
      type: 'appointment',
      title: 'Appointment Confirmed',
      body: `${data.doctor.name} — ${date} at ${time}`,
    });

    return data;
  },

  async cancel(appointmentId) {
    const { error } = await supabase
      .from('appointments')
      .update({ status: 'cancelled' })
      .eq('id', appointmentId);
    if (error) throw error;
  },
};

// ============================================================
//  CONSULTATIONS
// ============================================================
export const ConsultationsAPI = {
  async startOrResume({ patientId, doctorId }) {
    // Check for existing active consultation
    const { data: existing } = await supabase
      .from('consultations')
      .select('*')
      .eq('patient_id', patientId)
      .eq('doctor_id', doctorId)
      .eq('status', 'active')
      .maybeSingle();

    if (existing) return existing;

    const { data, error } = await supabase
      .from('consultations')
      .insert({ patient_id: patientId, doctor_id: doctorId })
      .select()
      .single();
    if (error) throw error;

    // Opening message from doctor
    await supabase.from('messages').insert({
      consultation_id: data.id,
      sender_id: doctorId,
      text: "Hello! I've reviewed your intake form. How are you feeling today?",
    });

    return data;
  },

  async end(consultationId) {
    const { error } = await supabase
      .from('consultations')
      .update({ status: 'closed', ended_at: new Date().toISOString() })
      .eq('id', consultationId);
    if (error) throw error;
  },
};

// ============================================================
//  MESSAGES  (with realtime)
// ============================================================
export const MessagesAPI = {
  async list(consultationId) {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('consultation_id', consultationId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return data;
  },

  async send({ consultationId, senderId, text }) {
    const { data, error } = await supabase
      .from('messages')
      .insert({ consultation_id: consultationId, sender_id: senderId, text })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  // Subscribe to new messages in real time
  subscribe(consultationId, onMessage) {
    const channel = supabase
      .channel(`messages:${consultationId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `consultation_id=eq.${consultationId}` },
        (payload) => onMessage(payload.new)
      )
      .subscribe();
    return () => supabase.removeChannel(channel); // return unsubscribe fn
  },
};

// ============================================================
//  VITALS
// ============================================================
export const VitalsAPI = {
  async list(patientId) {
    const { data, error } = await supabase
      .from('vitals')
      .select('*')
      .eq('patient_id', patientId)
      .order('recorded_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async log({ patientId, bp, hr, spo2, temp, weight, glucose }) {
    const { data, error } = await supabase
      .from('vitals')
      .insert({ patient_id: patientId, bp, hr, spo2, temp, weight, glucose })
      .select()
      .single();
    if (error) throw error;
    return data;
  },
};

// ============================================================
//  PRESCRIPTIONS
// ============================================================
export const PrescriptionsAPI = {
  async list(patientId) {
    const { data, error } = await supabase
      .from('prescriptions')
      .select(`*, doctor:doctors(name, avatar, color)`)
      .eq('patient_id', patientId)
      .order('issued_at', { ascending: false });
    if (error) throw error;
    return data;
  },
};

// ============================================================
//  NOTIFICATIONS
// ============================================================
export const NotificationsAPI = {
  async list(userId) {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async markRead(notificationId) {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', notificationId);
    if (error) throw error;
  },
};
