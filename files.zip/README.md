# MediConnect — Deploy Guide
### React Native + Expo → Play Store + App Store

---

## 1. Prerequisites

| Tool | Install |
|---|---|
| Node 18+ | https://nodejs.org |
| Expo CLI | `npm install -g expo-cli` |
| EAS CLI | `npm install -g eas-cli` |
| Android Studio | https://developer.android.com/studio |
| Xcode 15+ (Mac only) | App Store on Mac |

---

## 2. Project Setup

```bash
# Clone / init project
npx create-expo-app mediconnect --template blank
cd mediconnect

# Copy in the files from this package:
#   screens/HomeScreen.jsx  → screens/
#   lib/supabase.js         → lib/
#   app.json                → root
#   eas.json                → root
#   .env.example            → .env  (then fill in values)

# Install dependencies
npm install @supabase/supabase-js
npm install @react-navigation/native @react-navigation/stack @react-navigation/bottom-tabs
npx expo install react-native-screens react-native-safe-area-context
npx expo install react-native-gesture-handler react-native-reanimated
npx expo install expo-notifications expo-font
```

---

## 3. Supabase Setup

1. Go to https://supabase.com → New project
2. Open **SQL Editor** → paste the contents of `supabase-schema.sql` → Run
3. Go to **Settings → API** → copy your **URL** and **anon key**
4. Paste them into your `.env` file:
   ```
   EXPO_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJh...
   ```
5. In Supabase Dashboard → **Database → Replication** → enable `messages` table for realtime

---

## 4. EAS Build Setup

```bash
# Login to your Expo account (create one free at expo.dev)
eas login

# Link project (updates eas.json with your projectId)
eas init

# Update app.json:
#   ios.bundleIdentifier   → com.yourcompany.mediconnect
#   android.package        → com.yourcompany.mediconnect
```

---

## 5. Development Build (test on device)

```bash
# Android APK (sideload on device)
eas build --platform android --profile development

# iOS Simulator (Mac only)
eas build --platform ios --profile development
```

---

## 6. Production Build

```bash
# Android → .aab for Play Store
eas build --platform android --profile production

# iOS → .ipa for App Store
eas build --platform ios --profile production
```

---

## 7. Publish to Play Store

1. Go to https://play.google.com/console → **Create app**
2. Fill in: title, description, screenshots (min 2), feature graphic (1024×500)
3. **Production → Create new release** → upload the `.aab` from EAS
4. Add a **Privacy Policy URL** (required — use https://app-privacy-policy-generator.nisrulz.com)
5. Complete the content rating questionnaire
6. Submit for review → **3–7 days**

### Auto-submit (optional)
```bash
# Create a Google Play service account and download JSON key
# Place it at ./google-play-service-account.json
eas submit --platform android --profile production
```

---

## 8. Publish to App Store

1. Go to https://appstoreconnect.apple.com → **New App**
2. Fill in: name, bundle ID (`com.yourcompany.mediconnect`), SKU
3. Upload screenshots for iPhone 6.5" and 5.5"
4. Add Privacy Policy URL
5. Submit for review → **1–3 days**

### Auto-submit
```bash
# Update eas.json submit.production.ios with your Apple credentials
eas submit --platform ios --profile production
```

---

## 9. Push Notifications (optional but recommended)

```bash
npx expo install expo-notifications
```

Supabase Edge Function to send notifications:
```js
// supabase/functions/send-notification/index.ts
import { serve } from 'https://deno.land/std/http/server.ts'
serve(async (req) => {
  const { expoPushToken, title, body } = await req.json()
  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to: expoPushToken, title, body, sound: 'default' }),
  })
  return new Response('ok')
})
```

---

## 10. Checklist Before Submitting

- [ ] App icon (1024×1024 PNG, no alpha)
- [ ] Splash screen
- [ ] Privacy policy URL
- [ ] `.env` values set correctly for production
- [ ] `app.json` bundle IDs updated from `yourname` to your real identifier
- [ ] `eas.json` Apple credentials filled in
- [ ] Tested on a real Android device
- [ ] Tested on a real iPhone (or TestFlight)
- [ ] Supabase RLS policies verified
- [ ] In-memory `DB` / `API` objects fully replaced with `lib/supabase.js`

---

## File Structure

```
mediconnect/
├── app.json                 ← Expo config (icons, permissions, bundle IDs)
├── eas.json                 ← EAS Build + Submit config
├── .env                     ← Your Supabase keys (never commit this)
├── .env.example             ← Template
├── supabase-schema.sql      ← Run once in Supabase SQL Editor
├── lib/
│   └── supabase.js          ← All API calls (replaces in-memory DB)
└── screens/
    └── HomeScreen.jsx       ← Converted RN screen (template for others)
```
