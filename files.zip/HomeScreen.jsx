// screens/HomeScreen.jsx
// ============================================================
//  HomeScreen — React Native conversion of the web HomeScreen
//  Replaces: div→View, span/p→Text, onClick→onPress,
//            inline CSS→StyleSheet, @keyframes→Animated
// ============================================================

import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Animated, Pressable, ActivityIndicator,
  StatusBar, SafeAreaView, Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  DoctorsAPI, VitalsAPI, AppointmentsAPI,
  NotificationsAPI, PrescriptionsAPI,
} from '../lib/supabase';

// ── Colour tokens (mirrors the web app) ──────────────────────
const C = {
  bg:       '#f0f4f8',
  surface:  '#ffffff',
  navy:     '#0f172a',
  slate:    '#475569',
  muted:    '#94a3b8',
  sky:      '#0ea5e9',
  violet:   '#8b5cf6',
  emerald:  '#10b981',
  amber:    '#f59e0b',
  red:      '#ef4444',
  border:   '#e2e8f0',
};

// ── Pulse animation hook ──────────────────────────────────────
function usePulse() {
  const anim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 0.4, duration: 750, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 1,   duration: 750, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return anim;
}

// ── Fade-up animation hook ────────────────────────────────────
function useFadeUp(trigger = true) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(10)).current;
  useEffect(() => {
    if (trigger) {
      Animated.parallel([
        Animated.timing(opacity,    { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.timing(translateY, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]).start();
    }
  }, [trigger]);
  return { opacity, transform: [{ translateY }] };
}

// ── Notification panel ────────────────────────────────────────
function NotifPanel({ notifications, onRead, onClose }) {
  const slideAnim = useRef(new Animated.Value(-20)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(slideAnim,   { toValue: 0, duration: 220, useNativeDriver: true }),
      Animated.timing(opacityAnim, { toValue: 1, duration: 220, useNativeDriver: true }),
    ]).start();
  }, []);

  const icons = { appointment: '📅', prescription: '💊', reminder: '🔔', general: '🔔' };

  return (
    <Animated.View style={[s.notifPanel, { opacity: opacityAnim, transform: [{ translateY: slideAnim }] }]}>
      <View style={s.notifHeader}>
        <Text style={s.notifTitle}>Notifications</Text>
        <TouchableOpacity onPress={onClose}><Text style={{ fontSize: 22, color: C.muted }}>×</Text></TouchableOpacity>
      </View>
      {notifications.map(n => (
        <TouchableOpacity key={n.id} onPress={() => onRead(n.id)} style={[s.notifRow, { opacity: n.read ? 0.5 : 1 }]}>
          <Text style={{ fontSize: 20 }}>{icons[n.type] || '🔔'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.notifItemTitle}>{n.title}</Text>
            <Text style={s.notifItemBody}>{n.body}</Text>
          </View>
          {!n.read && <View style={s.unreadDot} />}
        </TouchableOpacity>
      ))}
    </Animated.View>
  );
}

// ── Vitals Log Form ───────────────────────────────────────────
function VitalForm({ form, onChange, onSave, onCancel }) {
  const anim = useFadeUp(true);
  const fields = [
    ['bp',   'Blood Pressure', '120/80'],
    ['hr',   'Heart Rate',     'bpm'],
    ['spo2', 'SpO₂',           '%'],
    ['temp', 'Temperature',    '°F'],
  ];
  return (
    <Animated.View style={[anim, { marginTop: 14 }]}>
      <View style={s.vitalGrid}>
        {fields.map(([key, label, ph]) => (
          <View key={key} style={s.vitalField}>
            <Text style={s.fieldLabel}>{label}</Text>
            <TextInput
              value={form[key]}
              onChangeText={v => onChange(key, v)}
              placeholder={ph}
              placeholderTextColor={C.muted}
              style={s.vitalInput}
            />
          </View>
        ))}
      </View>
      <TouchableOpacity onPress={onSave} style={s.saveVitalBtn} activeOpacity={0.85}>
        <Text style={s.saveVitalBtnText}>Save Vitals →</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

// ── Main HomeScreen ───────────────────────────────────────────
export default function HomeScreen({ user, navigation }) {
  const insets = useSafeAreaInsets();
  const pulseOpacity = usePulse();

  const [doctors,       setDoctors]       = useState([]);
  const [vitals,        setVitals]        = useState([]);
  const [appointments,  setAppointments]  = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [showNotifs,    setShowNotifs]    = useState(false);
  const [showVitalForm, setShowVitalForm] = useState(false);
  const [vitalForm,     setVitalForm]     = useState({ bp: '', hr: '', spo2: '', temp: '' });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    if (!user?.id) return;
    try {
      const [docs, vit, appts, rx, notifs] = await Promise.all([
        DoctorsAPI.list({ availableOnly: false }),
        VitalsAPI.list(user.id),
        AppointmentsAPI.list(user.id),
        PrescriptionsAPI.list(user.id),
        NotificationsAPI.list(user.id),
      ]);
      setDoctors(docs);
      setVitals(vit);
      setAppointments(appts);
      setPrescriptions(rx);
      setNotifications(notifs);
    } finally {
      setLoading(false);
    }
  };

  const logVitals = async () => {
    if (!vitalForm.bp || !vitalForm.hr) return;
    const entry = await VitalsAPI.log({ patientId: user.id, ...vitalForm });
    setVitals(v => [entry, ...v]);
    setShowVitalForm(false);
    setVitalForm({ bp: '', hr: '', spo2: '', temp: '' });
  };

  const markRead = async (id) => {
    await NotificationsAPI.markRead(id);
    setNotifications(n => n.map(x => x.id === id ? { ...x, read: true } : x));
  };

  const latestVitals   = vitals[0] || {};
  const unreadCount    = notifications.filter(n => !n.read).length;
  const upcomingAppts  = appointments.filter(a => a.status === 'scheduled');
  const activeRx       = prescriptions.filter(p => p.status === 'active');
  const availableDocs  = doctors.filter(d => d.available).slice(0, 3);
  const HEALTH_SCORE   = 87;

  if (loading) {
    return (
      <View style={[s.center, { backgroundColor: C.bg }]}>
        <ActivityIndicator size="large" color={C.sky} />
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.navy }}>
      <StatusBar barStyle="light-content" />
      <ScrollView
        style={s.scroll}
        contentContainerStyle={{ paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        {/* ── Header ── */}
        <View style={s.header}>
          <View>
            <Text style={s.greeting}>GOOD MORNING</Text>
            <Text style={s.userName}>{user?.name || 'Patient'} 👋</Text>
          </View>
          <TouchableOpacity onPress={() => setShowNotifs(v => !v)} style={s.bellBtn}>
            <Text style={{ fontSize: 20 }}>🔔</Text>
            {unreadCount > 0 && (
              <View style={s.badge}>
                <Text style={s.badgeText}>{unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* ── Health Score Card ── */}
        <View style={s.healthCard}>
          <View>
            <Text style={s.healthLabel}>HEALTH SCORE</Text>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 6 }}>
              <Text style={s.healthScore}>{HEALTH_SCORE}</Text>
              <Text style={s.healthMax}>/100</Text>
            </View>
            <Text style={s.healthTrend}>+3 from last month</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={s.vitalsHeaderLabel}>LATEST VITALS</Text>
            {[
              ['BP',   latestVitals.bp  || '—'],
              ['HR',   latestVitals.hr  ? `${latestVitals.hr} bpm` : '—'],
              ['SpO₂', latestVitals.spo2 || '—'],
            ].map(([k, v]) => (
              <View key={k} style={s.vitalRow}>
                <Text style={s.vitalKey}>{k}</Text>
                <Text style={s.vitalVal}>{v}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* ── Notification Panel ── */}
        {showNotifs && (
          <NotifPanel
            notifications={notifications}
            onRead={markRead}
            onClose={() => setShowNotifs(false)}
          />
        )}

        <View style={s.body}>
          {/* ── Quick Actions ── */}
          <Text style={s.sectionLabel}>QUICK ACTIONS</Text>
          <View style={s.quickGrid}>
            {[
              { icon: '🩺', label: 'See a Doctor',   sub: 'Doctors online now',                  color: C.sky,     screen: 'Browse' },
              { icon: '📋', label: 'My Records',      sub: 'View health data',                    color: C.violet,  screen: 'Records' },
              { icon: '💊', label: 'Prescriptions',   sub: `${activeRx.length} active`,           color: C.emerald, screen: 'Records' },
              { icon: '📅', label: 'Appointments',    sub: upcomingAppts.length > 0 ? `${upcomingAppts.length} upcoming` : 'None scheduled', color: C.amber, screen: 'Records' },
            ].map(item => (
              <TouchableOpacity
                key={item.label}
                onPress={() => navigation.navigate(item.screen)}
                style={s.quickCard}
                activeOpacity={0.85}
              >
                <View style={[s.quickIcon, { backgroundColor: `${item.color}18` }]}>
                  <Text style={{ fontSize: 20 }}>{item.icon}</Text>
                </View>
                <Text style={s.quickLabel}>{item.label}</Text>
                <Text style={s.quickSub}>{item.sub}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* ── Log Vitals ── */}
          <View style={s.card}>
            <View style={s.cardRow}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Text style={{ fontSize: 20 }}>📊</Text>
                <View>
                  <Text style={s.cardTitle}>Log Today's Vitals</Text>
                  <Text style={s.cardSub}>Keep your health data current</Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => setShowVitalForm(v => !v)}
                style={s.logBtn}
                activeOpacity={0.8}
              >
                <Text style={s.logBtnText}>{showVitalForm ? 'Cancel' : '+ Log'}</Text>
              </TouchableOpacity>
            </View>
            {showVitalForm && (
              <VitalForm
                form={vitalForm}
                onChange={(k, v) => setVitalForm(f => ({ ...f, [k]: v }))}
                onSave={logVitals}
                onCancel={() => setShowVitalForm(false)}
              />
            )}
          </View>

          {/* ── Available Doctors ── */}
          <View style={s.sectionHeader}>
            <Text style={s.sectionLabel}>AVAILABLE NOW</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Browse')}>
              <Text style={s.seeAll}>See all →</Text>
            </TouchableOpacity>
          </View>
          {availableDocs.map(doc => (
            <TouchableOpacity
              key={doc.id}
              onPress={() => navigation.navigate('Doctor', { doctor: doc })}
              style={s.docCard}
              activeOpacity={0.85}
            >
              <View style={[s.docAvatar, { backgroundColor: `${doc.color}22` }]}>
                <Text style={[s.docAvatarText, { color: doc.color }]}>{doc.avatar}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.docName}>{doc.name}</Text>
                <Text style={s.docSpec}>{doc.specialty}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <View style={s.waitBadge}>
                  <Animated.View style={{ opacity: pulseOpacity, width: 6, height: 6, borderRadius: 3, backgroundColor: C.emerald, marginRight: 4 }} />
                  <Text style={s.waitText}>~{doc.wait_min}m</Text>
                </View>
                <Text style={s.docRating}>★ {doc.rating}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ── Styles ────────────────────────────────────────────────────
const s = StyleSheet.create({
  scroll:       { flex: 1, backgroundColor: C.bg },
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center' },

  // Header
  header:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', padding: 20, paddingTop: 16, backgroundColor: C.navy },
  greeting:     { fontSize: 11, color: 'rgba(255,255,255,0.5)', fontWeight: '600', letterSpacing: 1, marginBottom: 4 },
  userName:     { fontSize: 24, color: 'white', fontWeight: '600' },
  bellBtn:      { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  badge:        { position: 'absolute', top: -2, right: -2, width: 18, height: 18, borderRadius: 9, backgroundColor: C.red, alignItems: 'center', justifyContent: 'center' },
  badgeText:    { fontSize: 10, fontWeight: '700', color: 'white' },

  // Health card
  healthCard:   { margin: 16, marginTop: 4, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', flexDirection: 'row', justifyContent: 'space-between' },
  healthLabel:  { fontSize: 11, color: 'rgba(255,255,255,0.5)', fontWeight: '600', letterSpacing: 1, marginBottom: 4 },
  healthScore:  { fontSize: 42, color: 'white', fontWeight: '700', lineHeight: 46 },
  healthMax:    { fontSize: 13, color: 'rgba(255,255,255,0.5)', marginBottom: 6 },
  healthTrend:  { fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 4 },
  vitalsHeaderLabel: { fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, marginBottom: 6 },
  vitalRow:     { flexDirection: 'row', gap: 10, justifyContent: 'flex-end', marginBottom: 3 },
  vitalKey:     { fontSize: 12, color: 'rgba(255,255,255,0.45)' },
  vitalVal:     { fontSize: 12, color: 'white', fontWeight: '600' },

  // Notification panel
  notifPanel:   { backgroundColor: C.surface, margin: 16, marginTop: -8, borderRadius: 16, padding: 16, ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.12, shadowRadius: 20 }, android: { elevation: 8 } }) },
  notifHeader:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  notifTitle:   { fontSize: 14, fontWeight: '700', color: C.navy },
  notifRow:     { flexDirection: 'row', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f1f5f9', alignItems: 'flex-start' },
  notifItemTitle: { fontSize: 13, fontWeight: '600', color: C.navy },
  notifItemBody:  { fontSize: 12, color: C.muted, marginTop: 2 },
  unreadDot:    { width: 8, height: 8, borderRadius: 4, backgroundColor: C.sky, marginTop: 6 },

  // Body
  body:         { padding: 16, backgroundColor: C.bg },
  sectionLabel: { fontSize: 11, fontWeight: '700', color: C.muted, letterSpacing: 1, marginBottom: 12 },
  sectionHeader:{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 8 },
  seeAll:       { fontSize: 13, color: C.sky, fontWeight: '600' },

  // Quick actions
  quickGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  quickCard:    { width: '47.5%', backgroundColor: C.surface, borderRadius: 16, padding: 16 },
  quickIcon:    { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  quickLabel:   { fontSize: 14, fontWeight: '600', color: '#1e293b', marginBottom: 2 },
  quickSub:     { fontSize: 12, color: C.muted },

  // Vitals card
  card:         { backgroundColor: C.surface, borderRadius: 16, padding: 14, marginBottom: 20 },
  cardRow:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardTitle:    { fontSize: 14, fontWeight: '600', color: C.navy },
  cardSub:      { fontSize: 12, color: C.muted, marginTop: 2 },
  logBtn:       { backgroundColor: `${C.sky}18`, borderRadius: 10, paddingVertical: 6, paddingHorizontal: 12 },
  logBtnText:   { fontSize: 12, fontWeight: '700', color: C.sky },

  // Vital form
  vitalGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 },
  vitalField:   { width: '47.5%' },
  fieldLabel:   { fontSize: 11, color: C.muted, marginBottom: 4, fontWeight: '600' },
  vitalInput:   { backgroundColor: '#f8fafc', borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 9, fontSize: 13, color: C.navy },
  saveVitalBtn: { backgroundColor: C.navy, borderRadius: 12, padding: 12, alignItems: 'center' },
  saveVitalBtnText: { color: 'white', fontSize: 13, fontWeight: '700' },

  // Doctor cards
  docCard:      { backgroundColor: C.surface, borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 10, ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8 }, android: { elevation: 2 } }) },
  docAvatar:    { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  docAvatarText:{ fontSize: 15, fontWeight: '700' },
  docName:      { fontSize: 14, fontWeight: '600', color: '#1e293b' },
  docSpec:      { fontSize: 12, color: '#64748b', marginTop: 2 },
  waitBadge:    { flexDirection: 'row', alignItems: 'center', backgroundColor: `${C.emerald}18`, paddingVertical: 3, paddingHorizontal: 8, borderRadius: 20, marginBottom: 4 },
  waitText:     { fontSize: 11, color: C.emerald, fontWeight: '600' },
  docRating:    { fontSize: 12, color: C.muted },
});
